/*
NAME: Carlin Bany-Winters
COURSE: CSC 3130.02 Introduction to Algorithms
DATE: 01/25/2024
DESCRIPTION: This class contains the methods called in order to execute the algorithms that solve
    the problems posed in Assignment 1: Algorithm Analysis. The written algorithms begin @ ln. 85.
    The code written in ln. 11-76 serves to establish given variables and print to the console the
    input and output for each algorithm.
 */
public class Main {
    public static void main(String[] args) {
        Main m = new Main(); // Used to call methods containing the algorithms
        /*
        -----QUESTION 1: COMMON SUBSEQUENCE-----
        -> Algorithm begins @ ln. 86
         */
        System.out.println("-----QUESTION 1: COMMON SUBSEQUENCE-----");

        // Input
        String text1 = "almanac";
        String text2 = "albatross";
        System.out.println("Input: text1 = " + text1 + ", text2 = " + text2);

        // Output
        int output = m.q1CommonSubsequence(text1, text2); // Call method used to calculate output
        System.out.println("Output: " + output);

        System.out.println();

        /*
         -----QUESTION 3: NOT FIBONACCI-----
         -> Algorithm begins @ ln. 123
         */
        System.out.println("-----QUESTION 3: NOT FIBONACCI-----");

        // Input
        int numTerms = 433;
        System.out.println("Number of NotFibonacci terms: " + numTerms);

        // Output
        String sequence = m.q3NotFibonacci(numTerms); // Call method used to calculate output
        System.out.println("First " + numTerms + " terms in the NotFibonacci sequence:\n" + sequence);

        System.out.println();

        /*
         -----QUESTION 4: WHERE IN SEQUENCE-----
         -> Algorithm begins @ ln. 151
         */
        System.out.println("-----QUESTION 4: WHERE IN SEQUENCE-----");

        // Input
        int n = 8;
        System.out.println("Input: " + n);

        // Output
        int position = m.q4WhereInSequence(n); // Call method used to calculate output
        System.out.println("Output: " + position);

        System.out.println();

        /*
         -----QUESTION 5: REMOVE ELEMENT-----
         -> Algorithm begins @ ln. 204
         */
        System.out.println("-----QUESTION 5: REMOVE ELEMENT-----");

        // Input
        int[] nums = {3, 2, 2, 3};
        int val = 3;
        System.out.println("Input: nums = " + m.getArrayString(nums) + ", val = " + val);
                                           // -> String getArrayString(int[] nums) begins @ ln. 222

        // Output
        int numElements = m.q5RemoveElement(nums, val); // Call method used to calculate output
        System.out.println("Output: " + numElements);
    }
    /*
    -----QUESTION 1: COMMON SUBSEQUENCE-----
    Find common subsequence (if it exists) between the set of two input texts and return the length of
        the subsequence.
        @param text1 = input text
        @param text2 = input text
        @return int = the length of the subsequence
     */
    private int q1CommonSubsequence(String text1, String text2) {
        int length = 0; // Assume no common subsequence
        /*
        Base: the text used as a reference
        Compare: the text being compared to the base to find common characters
         */
        String base = text1;
        String compare = text2;
        int baseI = 0; // Start with the character at index=0 of the base text

        // We want the longer text to be the base to avoid index bounds error
        if(text2.length() > text1.length()) {
            // Re-assign base and compare texts if needed
            base = text2;
            compare = text1;
        }

        // Convert compare into an Array that we can iterate thru
        char[] compChar = compare.toCharArray();
        for(char c : compChar) {
            /*
            Check if the char in compare we are currently examining matches the char
            located at our current base index
             */
            if(c == base.charAt(baseI)) {
                length++; // Increase subsequence length if the two chars match
            }
            baseI++; // Increment the base index for the next comparison
        }
        return length;
    }
    /*
    -----QUESTION 3: NOT FIBONACCI-----
    Generate a number of terms of the NotFibonacci sequence given by the input.
    @param numTerms = the number of terms in the sequence being generated
    @return String = the generated terms, seperated by a (",")
     */
    private String q3NotFibonacci(int numTerms) {
        // Start with initial values 0 and 1
        long term1 = 0;
        long term2 = 1;
        // Starting values are automatically added to the final sequence
        StringBuilder sequence = new StringBuilder(term1 + ", " + term2);

        // Generate as many additional terms as given by numTerms
        for(int i = 2; i < numTerms; i++) {

            long nextTerm = (3 * term1) + (2 * term2);
            // Add the new term to the sequence
            sequence.append(", ").append(nextTerm);

            // Update the terms that will be used for the next term generation
            term1 = term2;
            term2 = nextTerm;
        }

        return sequence.toString();
    }
    /*
    -----QUESTION 4: WHERE IN SEQUENCE-----
    Find the index of a given number within the NotFibonacci sequence, or the index of the next lowest
        number if the target is not in the sequence.
        @param n = the target value
        @return int = the position of the given value, or the position of the next lowest value
     */
    private int q4WhereInSequence(int n) {
        int position;

        // Start with initial values 0 and 1
        long term1 = 0;
        long term2 = 1;
        /*
        Determine whether the target value 'n' can be found in our initial values, or if
        additional term in the sequence need to be generated
         */
        switch(n) {
            case 0 -> position = 1; // n was found at 1st position in sequence
            case 1 -> position = 2; // n was found at 2nd position in sequence
            default -> {
                /*
                n was not found -> start generating additional terms starting at 3rd position
                until n OR the next lowest value in sequence is found
                 */
                position = 3;
                boolean found = false;
                while( !found ) {
                    long nextTerm = (3 * term1) + (2 * term2);

                    if(nextTerm == n) {
                        // A match for n was found at the current position
                        found = true;
                    }
                    else if(nextTerm > n) {
                        // The value at current position is higher than n
                        // n is not in sequence -> next lowest value located at previous position
                        position = position - 1;
                        found = true;
                    }
                    else {
                        // Update the terms that will be used for the next term generation
                        term1 = term2;
                        term2 = nextTerm;
                        // Increment the position of the next generated term
                        position++;
                    }
                }
            }
        }
        return position;
    }
    /*
    -----QUESTION 5: REMOVE ELEMENT-----
    Given a list of integers, remove the target val from the list and return the number of
        elements removed.
        @param nums = list of integers
        @param val = the target number being removed
        @return int = the number of elements removed
     */
    private int q5RemoveElement(int[] nums, int val) {
        int count = 0;

        for(int i = 0; i < nums.length; i++) {
            if(nums[i] != val) {
                nums[count++] = nums[i];
            }
        }

        return count;
    }
    /*
    !NOT AN ASSIGNED ALGORITHM - USED ONLY FOR EXPRESSING THE INPUT OF QUESTION 5 AS A STRING!
    Given an array of integers, return that same array in String form in the following format:
        "[array[0], array[1], array[2], ..., array[n]]"
        @param nums = given array
        @return String = given array in String form
     */
    private String getArrayString(int[] nums) {
        StringBuilder numsString = new StringBuilder("[" + nums[0]);
        for(int i = 1; i < nums.length; i++) {
            numsString.append(", ").append(nums[i]);
        }
        return numsString + "]";
    }
}